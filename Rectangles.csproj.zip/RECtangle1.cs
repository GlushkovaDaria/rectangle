﻿using System;

namespace Rectangles
{
	public static class RectanglesTask
	{
		// Пересекаются ли два прямоугольника (пересечение только по границе также считается пересечением)
		public static bool AreIntersected(Rectangle r1, Rectangle r2)
		{
            // так можно обратиться к координатам левого верхнего угла первого прямоугольника: r1.Left, r1.Top
            if (r1.Left <= r2.Left && r2.Left <= r1.Right || r1.Left <= r2.Right && r2.Right <= r1.Right)
            {
                if (r1.Top <= r2.Top && r2.Top <= r1.Bottom || r1.Top <= r2.Bottom && r2.Bottom <= r1.Bottom)
                    return true;
            }
            else return false;
		}

        //if ((r1.Left <= r2.Left && r2.Left <= r1.Right) && (r1.Top <= r2.Top && r2.Top <= r1.Bottom) 
        //return true;

        // Площадь пересечения прямоугольников
        public static int IntersectionSquare(Rectangle r1, Rectangle r2)
		{
            if (AreIntersected(r1, r2) == true)
            {
                int a1 = r1.Width, b1 = r1.Height, a2 = r2.Width, b2 = r2.Height;
                int minW = Math.Min(a1, a2);
                int minH = Math.Min(b1, b2);

                if (r1.Left >= r2.Left && r1.Top >= r2.Top)
                    return Math.Min(b2 + r2.Top - r1.Top, minH) * Math.Min(a2 + r2.Left - r1.Left, minW);
                else if (r1.Left >= r2.Left && r1.Top <=r2.Top)
                    return Math.Min(a2 + r2.Left - r1.Left, minW) * Math.Min(b1 + r1.Top - r2.Top, minH);
                else if (r1.Left <= r2.Left && r1.Top >= r2.Top)
                    return Math.Min(a1 + r1.Left - r2.Left, minW) * Math.Min(b2 + r2.Top - r1.Top, minH);
                else return Math.Min(b1 + r1.Top - r2.Top, minH) * Math.Min(a1 + r1.Left - r2.Left, minW);
            } else return 0;
		}

		// Если один из прямоугольников целиком находится внутри другого — вернуть номер (с нуля) внутреннего.
		// Иначе вернуть -1
		// Если прямоугольники совпадают, можно вернуть номер любого из них.
		public static int IndexOfInnerRectangle(Rectangle r1, Rectangle r2)
		{
            int a1 = r1.Width, b1 = r1.Height, a2 = r2.Width, b2 = r2.Height;
            int s1 = a1 * b1, s2 = a2 * b2;

            if (((IntersectionSquare(r1, r2) == s1) && s1 != 0) || (s1 == 0 && r1.Left >= r2.Left && r1.Top >= r2.Top && r1.Left <= a2 + r2.Left && r1.Top <= b2 + r2.Top))
                return 0;
            else if (((IntersectionSquare(r1, r2) == s2) && s2 != 0) || (s2 == 0 && r1.Left <= r2.Left && r1.Top <= r2.Top && r2.Left <= a1 + r1.Left && r2.Top <= b1 + r1.Top))
                return 1;
            else return -1;
		}
	}
}